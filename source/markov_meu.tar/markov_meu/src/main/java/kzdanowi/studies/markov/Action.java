/**
 * @author Konrad Zdanowicz (zdanowicz.konrad@gmail.com)
 * 
 */
package kzdanowi.studies.markov;

/**
 * 
 */
public enum Action {
	RIGHT,TOP,LEFT,BOTTOM,NONE;
}
